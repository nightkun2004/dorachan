<script setup>
import { ref } from 'vue';
import { RouterLink, RouterView} from 'vue-router'

const isMenuOpen = ref(false);

const toggleMenu = () => {
  isMenuOpen.value = !isMenuOpen.value;
};
</script>

<template>
    <div class="flex justify-between sticky top-0 items-center px-5 nav-main tn">
        <div class="nav-left flex mx-auto container items-center">
            <div class="logo w-64">
                <a href="/">
                    <img src="https://chinesedora.com/images/2020newlogo.png" alt="logo">
                </a>
            </div>
            <!-- Menu Toggle Button for Mobile -->
            <button @click="toggleMenu" class="md:hidden p-2 text-white bg-sky-600 rounded-2xl shadow">
                <svg v-if="!isMenuOpen" class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16m-7 6h7"></path>
                </svg>
                <svg v-if="isMenuOpen" class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
                </svg>
            </button>
            <!-- Menu Container -->
            <div :class="{ 'block': isMenuOpen, 'hidden': !isMenuOpen }" class="menus z-50 flex flex-col w-full md:flex  md:flex-row md:w-auto">
                <ul class="list-none flex flex-col md:flex-row">
                    <li class="relative group hidden md:block">
                        <a href="#" class="flex items-center p-4 text-white">
                            <div class="bg-news w-4 h-4 mr-2"></div>
                            ข่าวสาร
                        </a>
                        <ul class="absolute hidden mt-2 w-48 bg-white shadow-md rounded-md group-hover:block right-0">
                            <li>
                                <a href="#" class="block px-4 py-2 text-gray-700 hover:bg-gray-100">ข่าวเดอะมูฟวี่</a>
                            </li>
                            <li>
                                <a href="#" class="block px-4 py-2 text-gray-700 hover:bg-gray-100">ข่าวล่าสุด</a>
                            </li>
                            <li class="relative group">
                                <a href="#" class="block px-4 py-2 text-gray-700 hover:bg-gray-100">หมวดหมู่</a>
                                <span class="absolute right-2 top-2 text-blue-400">></span>
                                <ul class="absolute left-full top-0 hidden mt-2 w-48 bg-white shadow-md rounded-md group-hover:block">
                                    <li>
                                        <a href="#" class="block px-4 py-2 text-gray-700 hover:bg-gray-100">เดอะมูฟวี่</a>
                                    </li>
                                    <li>
                                        <a href="#" class="block px-4 py-2 text-gray-700 hover:bg-gray-100">สินค้า</a>
                                    </li>
                                    <li>
                                        <a href="#" class="block px-4 py-2 text-gray-700 hover:bg-gray-100">กิจกรรม</a>
                                    </li>
                                </ul>
                            </li>
                        </ul>
                    </li>

                    <li class="relative group hidden md:block">
                        <a href="#" class="flex items-center p-4 text-white">
                            <div class="bg-hopter w-4 h-4 mr-2"></div>
                            อนิเมะ
                        </a>
                        <ul class="absolute hidden mt-2 w-48 bg-white shadow-md rounded-md group-hover:block right-0">
                            <li>
                                <a href="#" class="block px-4 py-2 text-gray-700 hover:bg-gray-100">การ์ตูนต้นฉบับ</a>
                            </li>
                            <li>
                                <a href="#" class="block px-4 py-2 text-gray-700 hover:bg-gray-100">ซี่รีย์</a>
                            </li>
                            <li class="relative group">
                                <a href="#" class="block px-4 py-2 text-gray-700 hover:bg-gray-100">แอนิเเมชั่น</a>
                                <span class="absolute right-2 top-2 text-blue-400">></span>
                                <ul class="absolute left-full top-0 hidden mt-2 w-48 bg-white shadow-md rounded-md group-hover:block">
                                    <li>
                                        <a href="#" class="block px-4 py-2 text-gray-700 hover:bg-gray-100">เดอะมูฟวี่</a>
                                    </li>
                                    <li>
                                        <a href="#" class="block px-4 py-2 text-gray-700 hover:bg-gray-100">ญี่ปุ่น</a>
                                    </li>
                                    <li>
                                        <a href="#" class="block px-4 py-2 text-gray-700 hover:bg-gray-100">ไทย</a>
                                    </li>
                                </ul>
                            </li>
                        </ul>
                    </li>
                </ul>
                <!-- Mobile Menu -->
                <ul :class="{ 'block': isMenuOpen, 'hidden': !isMenuOpen }" class="absolute inset-x-0 top-11  md:hidden transition-transform transform mobile-menus">
                    <li>
                        <a href="#" class="block px-4 py-2  hover:bg-blue-400 text-white">ข่าวสาร</a>
                    </li>
                    <li>
                        <a href="#" class="block px-4 py-2  hover:bg-blue-400 text-white">ข่าวล่าสุด</a>
                    </li>
                    <li>
                        <a href="#" class="block px-4 py-2  hover:bg-blue-400 text-white">ข่าวเดอะมูฟวี่</a>
                    </li>
                </ul>
            </div>
        </div>
        <div class="nav-right hidden md:block">
            <div class="search__box flex">
                <input type="search" name="search" placeholder="ค้นหาเลย..." class="rounded outline-none px-3 py-2">
                <button type="submit" class="bg-blue-300 rounded text-white px-3 py-2">ค้นหา</button>
            </div>
        </div>
    </div>
</template>

<style scoped>
.nav-main,
.mobile-menus {
    background-color: #0e90ce;
    z-index: 99;
}

.bg-news {
    width: 32px;
    height: 32px;
    background: url(https://chinesedora.com/images/3636/css_sprites-1.png) -114px -10px;
}

.bg-hopter {
    width: 32px;
    height: 32px;
    background: url(https://chinesedora.com/images/3636/css_sprites-1.png) -62px -62px;
}

.mobile-menus {
    transition: transform 0.3s ease-in-out;
    transform: translateY(-100%);
}

.mobile-menus.block {
    transform: translateY(0%);
}
</style>
