<script setup>
import { useRoute } from 'vue-router'
import { RouterLink } from 'vue-router';
</script>

<template>
    <div class="posts grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-2">
        <!-- Post -->
        <router-link :to="{ name: 'read', params: { id: 324 } }">
            <div class="post relative bg-white shadow rounded">

                <img src="https://contents.dora-world.com/uassets/14f/4cd79cc596cbed53cfff86293c721/thumb.jpeg"
                    alt="img">


                <p class="bg-blue-500 rounded-lg px-4 py-2 absolute top-0 text-white">ข่าวสาร</p>
                <div class="title-post px-4 py-3">
                    <h3 class="text-black font-bold">
                        Lorem ipsum dolor sit amet consectetur adipisicing elit. Ipsam, deserunt.
                    </h3>
                </div>
            </div>
        </router-link>
        <router-link :to="{ name: 'read', params: { id: 4534 } }">
            <div class="post relative bg-white shadow rounded">

                <img src="https://contents.dora-world.com/uassets/14f/4cd79cc596cbed53cfff86293c721/thumb.jpeg"
                    alt="img">


                <p class="bg-blue-500 rounded-lg px-4 py-2 absolute top-0 text-white">ข่าวสาร</p>
                <div class="title-post px-4 py-3">
                    <h3 class="text-black font-bold">
                        Lorem ipsum dolor sit amet consectetur adipisicing elit. Ipsam, deserunt.
                    </h3>
                </div>
            </div>
        </router-link>
        <router-link :to="{ name: 'read', params: { id: 4534 } }">
            <div class="post relative bg-white shadow rounded">

                <img src="https://contents.dora-world.com/uassets/14f/4cd79cc596cbed53cfff86293c721/thumb.jpeg"
                    alt="img">


                <p class="bg-blue-500 rounded-lg px-4 py-2 absolute top-0 text-white">ข่าวสาร</p>
                <div class="title-post px-4 py-3">
                    <h3 class="text-black font-bold">
                        Lorem ipsum dolor sit amet consectetur adipisicing elit. Ipsam, deserunt.
                    </h3>
                </div>
            </div>
        </router-link>
        <router-link :to="{ name: 'read', params: { id: 4534 } }">
            <div class="post relative bg-white shadow rounded">

                <img src="https://contents.dora-world.com/uassets/14f/4cd79cc596cbed53cfff86293c721/thumb.jpeg"
                    alt="img">


                <p class="bg-blue-500 rounded-lg px-4 py-2 absolute top-0 text-white">ข่าวสาร</p>
                <div class="title-post px-4 py-3">
                    <h3 class="text-black font-bold">
                        Lorem ipsum dolor sit amet consectetur adipisicing elit. Ipsam, deserunt.
                    </h3>
                </div>
            </div>
        </router-link>
        <router-link :to="{ name: 'read', params: { id: 4534 } }">
            <div class="post relative bg-white shadow rounded">

                <img src="https://contents.dora-world.com/uassets/14f/4cd79cc596cbed53cfff86293c721/thumb.jpeg"
                    alt="img">


                <p class="bg-blue-500 rounded-lg px-4 py-2 absolute top-0 text-white">ข่าวสาร</p>
                <div class="title-post px-4 py-3">
                    <h3 class="text-black font-bold">
                        Lorem ipsum dolor sit amet consectetur adipisicing elit. Ipsam, deserunt.
                    </h3>
                </div>
            </div>
        </router-link>
        <router-link :to="{ name: 'read', params: { id: 4534 } }">
            <div class="post relative bg-white shadow rounded">

                <img src="https://contents.dora-world.com/uassets/14f/4cd79cc596cbed53cfff86293c721/thumb.jpeg"
                    alt="img">


                <p class="bg-blue-500 rounded-lg px-4 py-2 absolute top-0 text-white">ข่าวสาร</p>
                <div class="title-post px-4 py-3">
                    <h3 class="text-black font-bold">
                        Lorem ipsum dolor sit amet consectetur adipisicing elit. Ipsam, deserunt.
                    </h3>
                </div>
            </div>
        </router-link>
        <router-link :to="{ name: 'read', params: { id: 4534 } }">
            <div class="post relative bg-white shadow rounded">

                <img src="https://contents.dora-world.com/uassets/14f/4cd79cc596cbed53cfff86293c721/thumb.jpeg"
                    alt="img">


                <p class="bg-blue-500 rounded-lg px-4 py-2 absolute top-0 text-white">ข่าวสาร</p>
                <div class="title-post px-4 py-3">
                    <h3 class="text-black font-bold">
                        Lorem ipsum dolor sit amet consectetur adipisicing elit. Ipsam, deserunt.
                    </h3>
                </div>
            </div>
        </router-link>

    </div>
</template>

<style scoped></style>
