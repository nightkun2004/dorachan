<script setup>
</script>

<template>
    <footer class="bg-gray-900 text-white py-8 mt-5">
        <div class="container mx-auto px-4">
            <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
                <!-- Section 1: About Us -->
                <div>
                    <h3 class="text-xl font-bold mb-4">เกี่ยวกับเรา</h3>
                    <p class="text-gray-400">
                        เราเป็นเว็บไซต์ที่นำเสนอข่าวสารเกี่ยวกับอนิเมะและกิจกรรมต่างๆ ในวงการนี้ พร้อมกับให้บริการข้อมูลที่น่าสนใจอีกมากมาย
                    </p>
                </div>

                <!-- Section 2: Quick Links -->
                <div>
                    <h3 class="text-xl font-bold mb-4">ลิงก์ด่วน</h3>
                    <ul class="space-y-2">
                        <li><a href="/" class="text-gray-400 hover:text-white">หน้าแรก</a></li>
                        <li><a href="#" class="text-gray-400 hover:text-white">ข่าวสาร</a></li>
                        <li><a href="#" class="text-gray-400 hover:text-white">เกี่ยวกับเรา</a></li>
                    </ul>
                </div>

                <!-- Section 3: Contact Info -->
                <div>
                    <h3 class="text-xl font-bold mb-4">ติดต่อเรา</h3>
                    <ul class="space-y-2">
                        <li><i class="fas fa-envelope mr-2"></i> <a href="mailto:info@example.com" class="text-gray-400 hover:text-white">info@test.com</a></li>
                        <li><i class="fas fa-phone mr-2"></i> <a href="tel:+1234567890" class="text-gray-400 hover:text-white">+123 456 7890</a></li>
                    </ul>
                </div>
            </div>

            <hr class="my-8 border-gray-700">

            <!-- Footer Bottom -->
            <div class="text-center text-gray-500">
                <p>Dora-Thai &copy; 2024 Fujiko Pro, Shogakukan, TV Asahi, Shinei, ADK</p>
            </div>
        </div>
    </footer>
</template>

<style scoped>
footer {
    background-color: #1a202c;
}

a:hover {
    color: #e2e8f0;
}
</style>
