<script setup>
import { useRoute } from 'vue-router'
import Nav from '@/components/Nav.vue';
import Footer from '@/components/Footer.vue';

const route = useRoute()
const id = route.params.id
</script>

<template>

  <Nav />

  <main class="container mx-auto bg-white rounded-lg mt-5 px-5 py-4 shadow-sm">
    <h2> <a href="/">หน้าหลัก</a> / <span class="text-gray-600 font-light">{{ id }}</span></h2>
    <div class="read">
      <div class="title flex justify-center flex-col">
        <h3 class="font-medium text-base text-center md:text-2xl">Lorem ipsum dolor sit amet consectetur adipisicing
          elit. Quasi, quas?</h3>
        <hr class="mb-5 mt-3">
        <div class="Author flex items-center">
          <div class="profile">
            <img src="../assets/logo/avatar.jpg" alt="profile Author" class="w-10 h-10 rounded-full">
          </div>
          <h2 class="Author-test pl-5 flex items-center flex-col">
            <p class="text-gray-500">Username Author</p>
            <span style="font-size: 12px;">เขียนเมื่อ: 9/9/2024</span>
          </h2>
        </div>
        <hr class="mb-5 mt-6">
      </div>


      <!-- =======================================Main Content =============================== -->
      <div class="content text-base font-normal">
        Lorem, ipsum dolor sit amet consectetur adipisicing elit. Exercitationem facere reiciendis sed amet quae! Ullam
        voluptatibus, non voluptas pariatur iusto quam, aspernatur fuga distinctio esse doloribus corporis ex laborum
        repellat delectus eaque quasi? Ipsum tempore incidunt tenetur temporibus, vel repellat officiis natus
        distinctio. Molestias consectetur perspiciatis, repudiandae tempora corrupti iste quae aspernatur quia vitae
        numquam aperiam, minima laborum totam. Dolor sequi tempore ut deleniti iusto, fugiat pariatur, odit est
        voluptates, hic maiores! Laborum, in. Mollitia dicta, delectus ad at deleniti dolorem placeat, sint reiciendis
        laboriosam odit, accusantium alias perferendis quos beatae explicabo nemo maiores consequatur labore unde
        aliquid. Hic ex commodi quae perferendis eius molestiae placeat quisquam laudantium consequuntur, ipsam itaque
        aperiam, labore sed ipsa quibusdam reiciendis id ratione dicta modi quia ad voluptate. Ea esse expedita dolores
        omnis laudantium quis voluptates non, unde distinctio quisquam deserunt similique? Labore aperiam eveniet eum
        distinctio iusto provident esse unde suscipit, laudantium ducimus! Cum totam animi, fugiat, adipisci tenetur
        fuga sit facilis aut vero nam aspernatur reiciendis tempore provident quidem labore sunt rerum numquam unde
        magni aliquam dolore. Saepe, quae repellat non cumque impedit accusamus provident, necessitatibus error animi
        dolorum sequi. Doloremque id quo iusto deleniti a ullam dignissimos obcaecati saepe sequi quae.


        <div class="imgs">
          <img class="w-full h-auto" src="https://chinesedora.com/news/wp-content/uploads/2024/06/earth-tw-mandrain.jpg"
            alt="">
        </div>
      </div>

      <!-- ========================================================= Banner Ads ============================= -->
      <div class="grid grid-cols-1 gap-5 md:grid-cols-2 p-10">
        <div class=" bg-gray-600 rounded-md text-white text-center p-10">
          <p>200x100</p>
        </div>
        <div class=" bg-gray-600 rounded-md text-white text-center p-10">
          <p>200x100</p>
        </div>
      </div>
    </div>
  </main>

  <Footer />
</template>


<style scoped></style>