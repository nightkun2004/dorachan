<script setup>
import Item from '@/components/Item.vue';
import Nav from '@/components/Nav.vue';
import Footer from '@/components/Footer.vue';
</script>

<template>
  <Nav />
  <main class="container mx-auto bg-white rounded-md p-5 shadow-lg mt-5 transition-all duration-300 bg-dora-sky">
    <div class="Mv_nobi"></div>
    <div class="mv_dora"></div>
    <div class="mv_jai"></div>
    <div class="mv_suneo"></div>
    <div class="mv_shizuka"></div>
    <div class="title flex justify-between mb-5 text-white">
      <h2 class="border-l-4 border-blue-500 font-light pl-3">ข่าวสารอัพเดต</h2>
      <div class="bg-blue-500 relative rounded-full px-4 py-2 flex justify-end text-white">
        <a href="#" target="_blank">ดูทั้งหมด</a>
      </div>
    </div>

    <div class="item_content h-auto">
      <Item />
    </div>
  </main>

  <Footer />
</template>

<style scoped>
.bg-dora-sky {
  background-image: url("../assets/bg/mv_bg.png");
  background-repeat: no-repeat;
  background-size: cover;
  position: relative;
}

.Mv_nobi {
  background-image: url("../assets/bg/mv_nobita.png");
  background-repeat: no-repeat;
  background-size: contain;
  width: 100px;
  height: 200px;
  position: absolute;
  top: 5%;
  right: 30%;
  animation: float 5s infinite ease-in-out;
}


.mv_shizuka {
  background-image: url("../assets/bg/mv_shizuka.png");
  background-repeat: no-repeat;
  background-size: contain;
  width: 100px;
  height: 200px;
  position: absolute;
  top: 5%;
  right: 20%;
  animation: float 5s infinite ease-in-out;
}


.mv_jai {
  background-image: url("../assets/bg/mv_jai.png");
  background-repeat: no-repeat;
  background-size: contain;
  width: 100px;
  height: 200px;
  position: absolute;
  top: 5%;
  left: 30%;
  animation: float 2s infinite ease-in-out;
}


.mv_suneo {
  background-image: url("../assets/bg/mv_suneo.png");
  background-repeat: no-repeat;
  background-size: contain;
  width: 70px;
  height: 200px;
  position: absolute;
  top: 5%;
  right: 55%;
  animation: float 2s infinite ease-in-out;
}


.mv_dora {
  background-image: url("../assets/logo/mv_dora.png");
  background-repeat: no-repeat;
  background-size: contain;
  width: 150px;
  height: 200px;
  position: absolute;
  top: 10%;
  right: 40%;
  animation: float 4s infinite ease-in-out;
}

.item_content {
  margin-top: 10%;
}

@media screen and (max-width: 480px) {
  .mv_suneo {
    left:5%;
    top: 10%;
    width: 80px;
    height: 80px;
  }
  .mv_jai {
    left: 20%;
  }
  .Mv_nobi {
    right: 15%;
    width: 100px;
    height: 100px;
  }
  .mv_shizuka{
    right: 2%;
    top: 15%;
    width: 90px;
    height: 90px;
  }
  .mv_dora {
    right: 35%;
    width: 100px;
    height: 100px;
  }
  .item_content {
    margin-top: 25%;
  }
}

@media screen and (max-width: 680px) {
  .mv_suneo {
    left:5%;
    top: 10%;
    width: 80px;
    height: 80px;
  }
  .mv_jai {
    left: 20%;
  }
  .Mv_nobi {
    right: 20%;
    width: 100px;
    height: 100px;
  }
  .mv_shizuka{
    right: 2%;
    top: 15%;
    width: 90px;
    height: 90px;
  }
  .mv_dora {
    right: 43%;
    width: 100px;
    height: 100px;
  }
  .item_content {
    margin-top: 25%;
  }
}

@media screen and (max-width: 880px) {
  .mv_suneo {
    left:5%;
    top: 10%;
    width: 80px;
    height: 80px;
  }
  .mv_jai {
    left: 20%;
  }
  .Mv_nobi {
    right: 15%;
    width: 100px;
    height: 100px;
  }
  .mv_shizuka{
    right: 2%;
    top: 15%;
    width: 90px;
    height: 90px;
  }
  .mv_dora {
    right: 35%;
    width: 100px;
    height: 100px;
  }
  .item_content {
    margin-top: 25%;
  }
}

@keyframes float {
  0% {
    transform: translateY(0);
    /* อยู่ในตำแหน่งเดิม */
  }

  50% {
    transform: translateY(-20px);
    /* ลอยขึ้น */
  }

  100% {
    transform: translateY(0);
    /* กลับลงมาอยู่ตำแหน่งเดิม */
  }
}

.title {
  display: flex;
  align-items: center;
  position: relative;
  border-radius: 1.6rem 0;
  background: var(--color-base-pink);
}

.title:before {
  background-image: url(/assets/images/top/top_icn_hd_pickup.webp);
}


@keyframes swing {
  0% {
    transform: rotate(0deg);
  }

  25% {
    transform: rotate(10deg);
  }

  50% {
    transform: rotate(20deg);
  }

  75% {
    transform: rotate(10deg);
  }

  100% {
    transform: rotate(0deg);
  }
}


.character-swing-mv_dora {
  width: 150px;
  height: auto;
  animation: swing 2s infinite;
  transform-origin: top center;
}
</style>
